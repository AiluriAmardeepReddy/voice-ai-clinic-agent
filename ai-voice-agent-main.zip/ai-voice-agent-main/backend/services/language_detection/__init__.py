"""Language detection service module."""
